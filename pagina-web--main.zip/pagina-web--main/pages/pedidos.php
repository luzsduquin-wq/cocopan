<div class="contenido">
    <h2>Realiza tu Pedido</h2>
    <p>¿Antojo de pan recién hecho? Llámanos para hacer tu pedido y recógelo en nuestra tienda.</p>
    <p><strong>Teléfono:</strong> +57 300 123 4567</p>
    <p><strong>Horario de atención:</strong> Lunes a Sábado de 7:00 AM a 8:00 PM.</p>
</div>
<img src="assets/img/rappi.jpg" alt="Realiza tu pedido"
    style="width:100%; max-width:300px; display:block; margin:20px auto;">