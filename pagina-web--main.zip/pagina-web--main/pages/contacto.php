<?php
include("conexion.php");
?>

<?php
if (isset($_POST['enviar'])) {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $factura = $_POST['factura'];
    $tipo = $_POST['tipo'];
    $mensaje = $_POST['mensaje'];

    echo "<script>alert('Gracias, $nombre. Hemos recibido tu $tipo correctamente.');</script>";
}
?>


<!-- Formulario de Factura y PQR -->
<div class="formulario-contacto">
    <h3>Formulario de Factura y PQR</h3>
    <p>Envíanos tus solicitudes, reclamos o consulta de factura. Te responderemos lo antes posible.</p>

    <form method="post" action="insertar.php">
        <div class="form-group">
            <label for="nombre">Nombre completo:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Tu nombre" required>
        </div>

        <div class="form-group">
            <label for="email">Correo electrónico:</label>
            <input type="email" id="email" name="email" placeholder="Tu correo" required>
        </div>

        <div class="form-group">
            <label for="factura">Número de factura (opcional):</label>
            <input type="text" id="factura" name="factura" placeholder="Ej: FAC-00123">
        </div>

        <div class="form-group">
            <label for="tipo">Tipo de solicitud:</label>
            <select id="tipo" name="tipo" required>
                <option value="">Selecciona una opción</option>
                <option value="peticion">Petición</option>
                <option value="queja">Queja</option>
                <option value="reclamo">Reclamo</option>
                <option value="factura">Consulta de factura</option>
            </select>
        </div>

        <div class="form-group">
            <label for="mensaje">Mensaje:</label>
            <textarea id="mensaje" name="mensaje" rows="4" placeholder="Describe tu solicitud" required></textarea>
        </div>

        <button type="submit" name="enviar">Enviar</button>
    </form>
</div>
<!-- Formulario de Factura y PQR -->
<div class="contenido">
    <h2>Contacto</h2>
    <p>Visítanos y disfruta del auténtico sabor de la panadería tradicional.</p>
    <p><strong>Dirección:</strong> cl 34 # 18-52 cerca al parque parkway, Bogotá, Colombia.</p>
    <p><strong>Email:</strong> hola@cocopan.com</p>
</div>