<div class="contenido">
    <!DOCTYPE html>
    <html lang="es">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Menú Panadería</title>

        <!-- Swiper CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

        <style>
            body {
                background: #fff8f0;
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 0;
                text-align: center;
            }

            .contenido {
                margin-top: 30px;
            }

            .contenido h1 {
                color: #c27b2d;
                font-size: 2em;
                margin-bottom: 10px;
            }

            .contenido ul {
                list-style: none;
                padding: 0;
                font-size: 1.1em;
                color: #333;
            }

            .contenido li {
                margin: 6px 0;
            }

            .images {
                margin-top: 40px;
            }

            .swiper {
                width: 90%;
                max-width: 600px;
                height: 360px;
                margin: 0 auto 50px;
                border-radius: 20px;
                overflow: hidden;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            }

            .swiper-slide {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                background: #fff;
            }

            .swiper-slide img {
                width: 85%;
                height: 240px;
                object-fit: cover;
                border-radius: 10px;
                margin-bottom: 10px;
            }

            .swiper-slide h3 {
                color: #444;
                font-size: 1.2em;
            }
        </style>
    </head>

    <body>

        <div class="contenido">
            <h1>Nuestro Menú</h1>

        </div>

        <div class="images">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="assets/img/pan artesanal.jpg" alt="pan artesanal">
                        <h3>Pan artesanal</h3>
                    </div>

                    <div class="swiper-slide">
                        <img src="assets/img/postres.jpg" alt="postres">
                        <h3>Postres</h3>
                    </div>

                    <div class="swiper-slide">
                        <img src="assets/img/wafles.jpg" alt="wafles">
                        <h3>Wafles</h3>
                    </div>

                    <div class="swiper-slide">
                        <img src="assets/img/gelatina.jpg" alt="gelatina">
                        <h3>Gelatina</h3>
                    </div>

                    <div class="swiper-slide">
                        <img src="assets/img/tortas.jpg" alt="tortas">
                        <h3>Tortas</h3>
                    </div>
                </div>

                <!-- Botones -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <!-- Paginación -->
                <div class="swiper-pagination"></div>
            </div>
        </div>

        <!-- Swiper JS -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

        <!-- Inicialización de Swiper -->
        <script>
            const swiper = new Swiper(".mySwiper", {
                loop: true,
                autoplay: {
                    delay: 2500,
                    disableOnInteraction: false,
                },
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                effect: "slide",
                speed: 600,
            });
        </script>

    </body>

    </html>